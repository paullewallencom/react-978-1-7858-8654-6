'use strict';
export const Config = {
  'urls':{
    'search' : 'https://websearchapi.herokuapp.com/v1/search/',
    'search.local' : 'http://localhost:5000/v1/search/'
  }
};
