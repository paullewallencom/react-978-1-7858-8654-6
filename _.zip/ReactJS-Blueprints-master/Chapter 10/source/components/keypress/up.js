//@flow
const up = (
  keys: Object
): bool => {
  return 38 in keys;
}
module.exports = up;
