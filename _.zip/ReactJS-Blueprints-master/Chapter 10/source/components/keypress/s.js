//@flow
const s = (
  keys: Object
): bool => {
  return 83 in keys;
}
module.exports = s;
