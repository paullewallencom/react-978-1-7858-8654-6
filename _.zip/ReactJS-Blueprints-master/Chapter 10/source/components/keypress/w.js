//@flow
const w = (
  keys: Object
): bool => {
  return 87 in keys;
}
module.exports = w;
