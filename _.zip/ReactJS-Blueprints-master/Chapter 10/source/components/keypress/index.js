import w from './w';
import s from './s';
import a from './a';
import d from './d';
import up from './up';
import down from './down';
import left from './left';
import right from './right';
import space from './space';

module.exports = {
  w,
  s,
  a,
  d,
  up,
  down,
  left,
  right,
  space
}
