//@flow
const d = (
  keys: Object
): bool => {
  return 68 in keys;
}
module.exports = d;
