//@flow
const s = (
  keys: Object
): bool => {
  return 40 in keys;
}
module.exports = s;
